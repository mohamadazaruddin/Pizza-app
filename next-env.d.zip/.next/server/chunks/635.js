"use strict";
exports.id = 635;
exports.ids = [635];
exports.modules = {

/***/ 635:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Homepage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(41);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_4__);





const settings = {
    dots: true,
    arrows: true,
    fade: true,
    infinite: true,
    autoplay: true,
    speed: 500,
    autoplaySpeed: 2000,
    slidesToShow: 1,
    slidesToScroll: 1
};
function Homepage() {
    //   const [slider, setSlider] = React.useState<Slider | null>(null);
    // These are the breakpoints which changes the position of the
    // buttons as the screen size changes
    //   const cards = [
    //     {
    //       image:
    //         "https://cdn.shopify.com/s/files/1/0057/8938/4802/files/STONE-1450WEB_445e032a-622d-4717-8718-8cbc67141636_1400x.jpg?v=1652696915",
    //     },
    //     {
    //       image:
    //         "https://cdn.shopify.com/s/files/1/0064/4435/1539/files/banner-custom-bottom-2_1920x.jpg?v=1616659104",
    //     },
    //     {
    //       image:
    //         "https://images.bewakoof.com/uploads/grid/app/flash-sale-desktop-banner-tshirts-1652671862.gif",
    //     },
    //   ];
    {
    /* <Slider {...settings} ref={(slider) => setSlider(slider)}>
          {cards.map((card, index) => (
            <Box key={index} height={"500px"} position="relative">
              <Image src={card.image} height="100%" w="100%" />
            </Box>
          ))}
        </Slider> */ }
    const details = [
        {
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__.FaPhoneAlt, {}),
            title: "000 (123) 456 7890",
            description: "A small river named Duden flows",
            pizza: "/pizza-1.jpg",
            meal: "Italian Pizza",
            mealdescription: "Far far away, behind the word mountains, far from the countries Vokalia and Consonantia"
        },
        {
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_4__.MdMyLocation, {}),
            title: "198 West 21th Street",
            description: "Suite 721 New York NY 10016",
            pizza: "/pizza-2.jpg",
            meal: "Greek Pizza",
            mealdescription: "Far far away, behind the word mountains, far from the countries Vokalia and Consonantia"
        },
        {
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_4__.MdAccessTimeFilled, {}),
            title: "Open Monday-Friday",
            description: "8:00am - 9:00pm",
            pizza: "/pizza-3.jpg",
            meal: "Caucasian Pizza",
            mealdescription: "Far far away, behind the word mountains, far from the countries Vokalia and Consonantia"
        },
        {
            meal: "American Pizza",
            pizza: "/pizza-4.jpg",
            mealdescription: "Far far away, behind the word mountains, far from the countries Vokalia and Consonantia"
        },
        {
            meal: "Tomatoe Pie",
            pizza: "/pizza-5.jpg",
            mealdescription: "Far far away, behind the word mountains, far from the countries Vokalia and Consonantia"
        },
        {
            meal: "Margherita",
            pizza: "/pizza-6.jpg",
            mealdescription: "Far far away, behind the word mountains, far from the countries Vokalia and Consonantia"
        }, 
    ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
        children: [
            " ",
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "stylesheet",
                type: "text/css",
                charSet: "UTF-8",
                href: "https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.css"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "stylesheet",
                type: "text/css",
                href: "https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick-theme.min.css"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                backgroundImage: "./bg_3.jpg",
                w: "100%",
                backgroundPosition: "center",
                backgroundRepeat: "no-repeat",
                backgroundSize: "cover",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                    py: "100px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    w: "100%",
                    h: "100%",
                    bg: "#0000009e",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                        textAlign: "center",
                        maxW: "50%",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                fontSize: "30px",
                                color: "#fac564",
                                fontFamily: "cursive",
                                m: "0",
                                children: "Welcome"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                                color: "#fff",
                                fontSize: "40px",
                                fontWeight: "normal",
                                m: "0",
                                textTransform: "uppercase",
                                children: "We cooked your desired Pizza Recipe"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                color: "#cfcfcf",
                                fontSize: "20px",
                                children: "A small river named Duden flows by their place and supplies it with the necessary regelialia."
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                mt: "25px",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                        bg: "#fac564",
                                        p: "16px 24px",
                                        border: "1px solid #fca564",
                                        mx: "10px",
                                        variant: "solid",
                                        children: "Check"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                        variant: "outline",
                                        p: "16px 24px",
                                        border: "1px solid #fca564",
                                        mx: "10px",
                                        bg: "transparent",
                                        color: "#fff",
                                        children: "Call us"
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                bg: "#000",
                p: "25px 25px",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    templateColumns: {
                        md: "repeat(3, 1fr)",
                        base: "repeat(1, 1fr)"
                    },
                    gap: 6,
                    children: details.map((element, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.GridItem, {
                            w: "100%",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                display: "flex",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                        color: "#fca564",
                                        display: "flex",
                                        mx: 10,
                                        mt: "5px",
                                        fontSize: "20px",
                                        children: element.icon
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                                                color: "#fff",
                                                m: "0",
                                                fontSize: "18px",
                                                children: element.title
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                                color: "gray",
                                                m: "10px 0px 0px 0px",
                                                children: element.description
                                            })
                                        ]
                                    })
                                ]
                            })
                        }, i))
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                py: "50px",
                backgroundImage: "./bg_4.jpg",
                w: "100%",
                backgroundPosition: "center",
                backgroundRepeat: "no-repeat",
                backgroundSize: "cover",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                    textAlign: "center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                            color: "#fff",
                            children: "HOT PIZZA MEALS"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            color: "gray",
                            mt: "20px",
                            children: [
                                "Far far away, behind the word mountains, far from the countries Vokalia ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                "and Consonantia, there live the blind texts."
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            templateColumns: {
                                md: "repeat(3, 1fr)",
                                base: "repeat(1, 1fr)"
                            },
                            gap: 0,
                            mt: "20px",
                            children: details.map((items, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.GridItem, {
                                    w: "100%",
                                    bg: "#00000059",
                                    mb: "20px",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                                backgroundImage: items.pizza,
                                                // height="100%"
                                                overflow: "hidden",
                                                w: "50%",
                                                backgroundPosition: "center",
                                                backgroundRepeat: "no-repeat",
                                                backgroundSize: "cover"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                                p: "15px",
                                                width: "50%",
                                                h: "100%",
                                                textAlign: "start",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                                                        fontSize: "20px",
                                                        color: "#fff",
                                                        display: "inline-block",
                                                        children: items.meal
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                                        color: "gray",
                                                        children: items.mealdescription
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                                        mt: "10px",
                                                        bg: "#fac564",
                                                        w: "100%",
                                                        border: "1px solid #fca564",
                                                        variant: "solid",
                                                        children: "Order"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }, i))
                        })
                    ]
                })
            })
        ]
    });
};


/***/ })

};
;